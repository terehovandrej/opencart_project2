from framework import MyWaits


def test_main_page_elements(browser, base_url):
    browser.get(base_url)
    my_waits = MyWaits(browser)
    my_waits.wait_element_by_id("top")
    my_waits.wait_element_by_id("common-home")
    my_waits.wait_element_by_id("top-links")
    my_waits.wait_element_by_id("menu")
    my_waits.wait_element_by_id("form-currency")


def test_product_card_page_elements(browser, base_url):
    browser.get(f"{base_url}index.php?route=product/product&path=57&product_id=49")
    my_waits = MyWaits(browser)
    my_waits.wait_element_by_css("#input-quantity")
    my_waits.wait_element_by_css("#button-cart")
    my_waits.wait_element_by_css("a.addthis_button_expanded")
    my_waits.wait_element_by_css("button[data-original-title='Add to Wish List']")
    my_waits.wait_element_by_css("button[data-original-title='Compare this Product']")


def test_login_page_elements(browser, base_url):
    browser.get(f"{base_url}index.php?route=account/login")
    my_waits = MyWaits(browser)
    my_waits.wait_element_by_link_text("My Account")
    my_waits.wait_element_by_link_text("Register")
    my_waits.wait_element_by_link_text("Login")
    my_waits.wait_element_by_link_text("Order History")
    my_waits.wait_element_by_link_text("Downloads")


def test_catalog_elements(browser, base_url):
    browser.get(f"{base_url}index.php?route=product/product&path=57&product_id=49")
    my_waits = MyWaits(browser)
    my_waits.wait_element_by_xpath("//button[@data-original-title='Add to Wish List']")
    my_waits.wait_element_by_xpath("//button[@data-original-title='Compare this Product']")
    my_waits.wait_element_by_xpath("//button[text()='Add to Cart']")
    my_waits.wait_element_by_xpath("//span[@id='cart-total']/..")
    my_waits.wait_element_by_xpath("//a[text()='Phones & PDAs']")


def test_admin_login_elements(browser, base_url):
    browser.get(f"{base_url}admin")
    my_waits = MyWaits(browser)
    my_waits.wait_element_by_class_name("container-fluid")
    my_waits.wait_element_by_class_name("navbar-static-top")
    my_waits.wait_element_by_class_name("col-sm-offset-4")
    my_waits.wait_element_by_class_name("panel-default")
    my_waits.wait_element_by_class_name("panel-title")
