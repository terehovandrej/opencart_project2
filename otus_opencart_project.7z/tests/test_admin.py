from time import sleep

from selenium.webdriver.common.by import By

from framework import MyWaits
from pages.admin_page import AdminPage
from pages.login_page import AdminLoginPage


def test_admin_login(login_page):
    login_page.login('user', 'bitnami1')
    admin_page = AdminPage()
    admin_page.f
    # login_page.find_element()


def test_admin_logout(browser, base_url):
    browser.get(f"{base_url}admin")
    my_waits = MyWaits(browser)
    username = my_waits.wait_element_by_xpath('//input[@name="username"]')
    username.send_keys('user')
    password = my_waits.wait_element_by_xpath('//input[@name="password"]')
    password.send_keys('bitnami1')
    login = my_waits.wait_element_by_xpath('//button[@type="submit"]')
    login.click()
    my_waits.wait_element_by_xpath('//a[text() = "John Doe "]')
    logout = my_waits.wait_element_by_xpath('//span[text() = "Logout"]')
    logout.click()
    my_waits.wait_element_by_xpath('//h1[text()=" Please enter your login details."]')


def test_go_to_products(browser, base_url):
    browser.get(f"{base_url}admin")
    my_waits = MyWaits(browser)
    username = my_waits.wait_element_by_xpath('//input[@name="username"]')
    username.send_keys('user')
    password = my_waits.wait_element_by_xpath('//input[@name="password"]')
    password.send_keys('bitnami1')
    login = my_waits.wait_element_by_xpath('//button[@type="submit"]')
    login.click()
    catalog = my_waits.wait_element_by_xpath('//a[text()=" Catalog"]')
    catalog.click()
    products = my_waits.wait_element_by_xpath('//a[text()="Products"]')
    products.click()
    my_waits.wait_element_by_xpath('//table')

