from framework import MyWaits


def test_main_page(browser, base_url):
    browser.get(f"{base_url}admin")
    my_waits = MyWaits(browser)

